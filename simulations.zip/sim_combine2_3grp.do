* sim_combine2_3grp

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\sim9_3grp.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\sim10_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim11_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim12_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim13_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim14_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim15_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim16_3grp.dta"

save "E:\ArielStuff\wtd_k_simulations\sim_sensitivity_all_3grp.dta", replace

collapse (mean) power_ks=rej_ks power_ad=rej_ad power_cvm=rej_cvm ///
         (count) nreps=rej_ks, by(condition re)
sort condition re

gen double se_ks   = sqrt(power_ks   * (1-power_ks)   / nreps)
gen double se_ad   = sqrt(power_ad   * (1-power_ad)   / nreps)
gen double se_cvm  = sqrt(power_cvm  * (1-power_cvm)  / nreps)

capture confirm file "E:\ArielStuff\wtd_k_simulations\sim_summary_3grp.dta"
if !_rc {
	preserve
		use "E:\ArielStuff\wtd_k_simulations\sim_summary_3grp.dta", clear
		keep if ntot == 2000
		gen double re = 0.6
		keep condition re power_ks power_ad power_cvm nreps se_ks se_ad se_cvm
		tempfile re06
		save `re06'
	restore
	append using `re06'
	sort condition re
}

save "E:\ArielStuff\wtd_k_simulations\sim_sensitivity_summary_3grp.dta", replace

di as txt _n "=== Weight-variability sensitivity: rejection rate by condition and re (k=3) ==="
list condition re nreps power_ks se_ks power_ad se_ad power_cvm se_cvm, ///
	sepby(condition) noobs

di as txt _n "=== Type I error across re (target = 0.05) ==="
list condition re nreps power_ks se_ks power_ad se_ad power_cvm se_cvm ///
	if condition == "null", noobs

foreach cond in null bulk tail diffuse {
	preserve
		keep if condition == "`cond'"
		quietly count
		if r(N) > 0 {
			sort re
			local ytitle "Rejection rate"
			local plottitle "Rejection rate vs. weight variability: `cond' (k=3)"
			if "`cond'" == "null" {
				local ytitle "Type I error (target = 0.05)"
			}
			twoway (line power_ks re, sort lcolor(red)    lwidth(medthick) msymbol(O)) ///
			       (line power_ad re, sort lcolor(blue)   lwidth(medthick) msymbol(D)) ///
			       (line power_cvm re, sort lcolor(green)  lwidth(medthick) msymbol(T)), ///
			       yline(0.05, lpattern(dash) lcolor(gs10)) ///
			       legend(order(1 "kstest (KS)" 2 "adtest (AD)" 3 "cvmtest (CVM)")) ///
			       ytitle("`ytitle'") ///
			       xtitle("Kish effective-sample-size ratio (re)") ///
			       title("`plottitle'") ///
			       name(sens_`cond'_3grp, replace)
			graph export "E:\ArielStuff\wtd_k_simulations\sens_`cond'_3grp.png", replace width(1200)
		}
	restore
}

di as txt _n "Done."
di as txt "Raw replicate-level data: sim_sensitivity_all_3grp.dta"
di as txt "Collapsed summary table: sim_sensitivity_summary_3grp.dta"
di as txt "Graphs: sens_null_3grp.png, sens_bulk_3grp.png, sens_tail_3grp.png, sens_diffuse_3grp.png"
