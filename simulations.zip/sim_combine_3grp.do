* sim_combine_3grp

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\sim1_3grp.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\sim2_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim3_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim4_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim5_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim6_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim7_3grp.dta"
append using "E:\ArielStuff\wtd_k_simulations\sim8_3grp.dta"

save "E:\ArielStuff\wtd_k_simulations\sim_all_3grp.dta", replace

collapse (mean) power_ks=rej_ks power_ad=rej_ad power_cvm=rej_cvm ///
         (count) nreps=rej_ks, by(condition ntot)
sort condition ntot

gen double se_ks   = sqrt(power_ks   * (1-power_ks)   / nreps)
gen double se_ad   = sqrt(power_ad   * (1-power_ad)   / nreps)
gen double se_cvm  = sqrt(power_cvm  * (1-power_cvm)  / nreps)

save "E:\ArielStuff\wtd_k_simulations\sim_summary_3grp.dta", replace

di as txt _n "=== Full summary: rejection rate by condition and N (k=3) ==="
list condition ntot nreps power_ks se_ks power_ad se_ad power_cvm se_cvm, ///
	sepby(condition) noobs

di as txt _n "=== Type I error (null condition; target = 0.05) ==="
list condition ntot nreps power_ks se_ks power_ad se_ad power_cvm se_cvm ///
	if condition == "null", noobs

preserve
	keep if condition == "bulk"
	sort ntot
	twoway (line power_ks ntot, sort lcolor(red)    lwidth(medthick) msymbol(O)) ///
	       (line power_ad ntot, sort lcolor(blue)   lwidth(medthick) msymbol(D)) ///
	       (line power_cvm ntot, sort lcolor(green)  lwidth(medthick) msymbol(T)), ///
	       yline(0.05, lpattern(dash) lcolor(gs10)) ///
	       legend(order(1 "kstest (KS)" 2 "adtest (AD)" 3 "cvmtest (CVM)")) ///
	       ytitle("Power (proportion rejecting at 0.05)") ///
	       xtitle("Total sample size") ///
	       title("Power vs. sample size: bulk (central) scenario, k=3") ///
	       name(power_bulk_3grp, replace)
	graph export "E:\ArielStuff\wtd_k_simulations\power_bulk_3grp.png", replace width(1200)
restore

preserve
	keep if condition == "tail"
	sort ntot
	twoway (line power_ks ntot, sort lcolor(red)    lwidth(medthick) msymbol(O)) ///
	       (line power_ad ntot, sort lcolor(blue)   lwidth(medthick) msymbol(D)) ///
	       (line power_cvm ntot, sort lcolor(green)  lwidth(medthick) msymbol(T)), ///
	       yline(0.05, lpattern(dash) lcolor(gs10)) ///
	       legend(order(1 "kstest (KS)" 2 "adtest (AD)" 3 "cvmtest (CVM)")) ///
	       ytitle("Power (proportion rejecting at 0.05)") ///
	       xtitle("Total sample size") ///
	       title("Power vs. sample size: tail scenario, k=3") ///
	       name(power_tail_3grp, replace)
	graph export "E:\ArielStuff\wtd_k_simulations\power_tail_3grp.png", replace width(1200)
restore

preserve
	keep if condition == "diffuse"
	sort ntot
	twoway (line power_ks ntot, sort lcolor(red)    lwidth(medthick) msymbol(O)) ///
	       (line power_ad ntot, sort lcolor(blue)   lwidth(medthick) msymbol(D)) ///
	       (line power_cvm ntot, sort lcolor(green)  lwidth(medthick) msymbol(T)), ///
	       yline(0.05, lpattern(dash) lcolor(gs10)) ///
	       legend(order(1 "kstest (KS)" 2 "adtest (AD)" 3 "cvmtest (CVM)")) ///
	       ytitle("Power (proportion rejecting at 0.05)") ///
	       xtitle("Total sample size") ///
	       title("Power vs. sample size: diffuse scenario, k=3") ///
	       name(power_diffuse_3grp, replace)
	graph export "E:\ArielStuff\wtd_k_simulations\power_diffuse_3grp.png", replace width(1200)
restore

preserve
	keep if condition == "null"
	sort ntot
	twoway (line power_ks ntot, sort lcolor(red)    lwidth(medthick) msymbol(O)) ///
	       (line power_ad ntot, sort lcolor(blue)   lwidth(medthick) msymbol(D)) ///
	       (line power_cvm ntot, sort lcolor(green)  lwidth(medthick) msymbol(T)), ///
	       yline(0.05, lpattern(dash) lcolor(gs10)) ///
	       legend(order(1 "kstest (KS)" 2 "adtest (AD)" 3 "cvmtest (CVM)")) ///
	       ytitle("Rejection rate under the null (target = 0.05)") ///
	       xtitle("Total sample size") ///
	       title("Type I error vs. sample size, k=3") ///
	       name(size_null_3grp, replace)
	graph export "E:\ArielStuff\wtd_k_simulations\size_null_3grp.png", replace width(1200)
restore

di as txt _n "Done."
di as txt "Raw replicate-level data: sim_all_3grp.dta"
di as txt "Collapsed summary table: sim_summary_3grp.dta"
di as txt "Graphs: power_bulk_3grp.png, power_tail_3grp.png, power_diffuse_3grp.png, size_null_3grp.png"

use "E:\ArielStuff\wtd_k_simulations\sim_all_3grp.dta", clear

gen byte diff_ad_ks    = rej_ad   - rej_ks
gen byte diff_cvm_ks   = rej_cvm  - rej_ks
gen byte diff_ad_cvm   = rej_ad   - rej_cvm

collapse (mean) mean_ad_ks=diff_ad_ks     mean_cvm_ks=diff_cvm_ks     mean_ad_cvm=diff_ad_cvm ///
         (sd)   sd_ad_ks=diff_ad_ks       sd_cvm_ks=diff_cvm_ks       sd_ad_cvm=diff_ad_cvm   ///
         (count) nreps=diff_ad_ks, by(condition ntot)
sort condition ntot

foreach pair in ad_ks cvm_ks ad_cvm {
	gen double se_`pair' = sd_`pair' / sqrt(nreps)
	gen double z_`pair'  = mean_`pair' / se_`pair'
	gen double p_`pair'  = 2*(1-normal(abs(z_`pair')))
}

save "E:\ArielStuff\wtd_k_simulations\sim_paired_diff_3grp.dta", replace

di as txt _n "=== Paired difference: AD - KS (positive = AD more powerful) ==="
list condition ntot nreps mean_ad_ks se_ad_ks z_ad_ks p_ad_ks, sepby(condition) noobs

di as txt _n "=== Paired difference: CVM - KS (positive = CVM more powerful) ==="
list condition ntot nreps mean_cvm_ks se_cvm_ks z_cvm_ks p_cvm_ks, sepby(condition) noobs

di as txt _n "=== Paired difference: AD - CVM (positive = AD more powerful) ==="
list condition ntot nreps mean_ad_cvm se_ad_cvm z_ad_cvm p_ad_cvm, sepby(condition) noobs

di as txt _n "Saved: sim_paired_diff_3grp.dta"
