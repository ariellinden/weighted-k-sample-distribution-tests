* posthoc_combine

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\posthoc1.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\posthoc2.dta"
append using "E:\ArielStuff\wtd_k_simulations\posthoc3.dta"
append using "E:\ArielStuff\wtd_k_simulations\posthoc4.dta"

save "E:\ArielStuff\wtd_k_simulations\posthoc_all.dta", replace

foreach t in ks ad cvm {
	quietly gen byte rej_`t'_omni = (p_`t'_omni < 0.05)

	foreach pair in refref ref1d ref2d {
		quietly gen byte raw_rej_`t'_`pair' = (p_`t'_`pair' < 0.05)
	}
	quietly gen byte raw_any_`t' = (raw_rej_`t'_refref==1 | raw_rej_`t'_ref1d==1 | raw_rej_`t'_ref2d==1)
	quietly gen byte raw_full_`t' = (raw_rej_`t'_ref1d==1 & raw_rej_`t'_ref2d==1 & raw_rej_`t'_refref==0)

	foreach adj in bonf sidak holm fdr {
		foreach pair in refref ref1d ref2d {
			quietly gen byte `adj'_rej_`t'_`pair' = (`adj'_`t'_`pair' < 0.05)
		}
		quietly gen byte `adj'_any_`t' = (`adj'_rej_`t'_refref==1 | `adj'_rej_`t'_ref1d==1 | `adj'_rej_`t'_ref2d==1)
		quietly gen byte `adj'_full_`t' = (`adj'_rej_`t'_ref1d==1 & `adj'_rej_`t'_ref2d==1 & `adj'_rej_`t'_refref==0)
	}
}

di as txt _n "============================================================"
di as txt "  (1) Family-wise error rate under the null (target ~ 0.05)"
di as txt "============================================================"

foreach t in ks ad cvm {
	di as txt _n "--- `t' ---"
	di as txt "  raw (unadjusted):"
	quietly summarize raw_any_`t' if condition=="null" & ntot==1000, meanonly
	di as txt "    n=1000: " as res %5.3f r(mean)
	quietly summarize raw_any_`t' if condition=="null" & ntot==4000, meanonly
	di as txt "    n=4000: " as res %5.3f r(mean)

	foreach adj in bonf sidak holm fdr {
		di as txt "  `adj':"
		quietly summarize `adj'_any_`t' if condition=="null" & ntot==1000, meanonly
		di as txt "    n=1000: " as res %5.3f r(mean)
		quietly summarize `adj'_any_`t' if condition=="null" & ntot==4000, meanonly
		di as txt "    n=4000: " as res %5.3f r(mean)
	}
}

di as txt _n "============================================================"
di as txt "  (2) Localization in the power scenarios"
di as txt "============================================================"

foreach cond in bulk tail diffuse {
	di as txt _n "########## `cond' ##########"
	foreach t in ks ad cvm {
		di as txt _n "--- `t', `cond' ---"
		di as txt "                        power(ref1-disc)  power(ref2-disc)  falsepos(ref-ref)  full-localization"

		di as txt "  raw, n=1000:      " _continue
		quietly summarize raw_rej_`t'_ref1d if condition=="`cond'" & ntot==1000, meanonly
		local a = r(mean)
		quietly summarize raw_rej_`t'_ref2d if condition=="`cond'" & ntot==1000, meanonly
		local b = r(mean)
		quietly summarize raw_rej_`t'_refref if condition=="`cond'" & ntot==1000, meanonly
		local c = r(mean)
		quietly summarize raw_full_`t' if condition=="`cond'" & ntot==1000, meanonly
		local d = r(mean)
		di as res %8.3f `a' "          " %8.3f `b' "          " %8.3f `c' "          " %8.3f `d'

		di as txt "  raw, n=4000:      " _continue
		quietly summarize raw_rej_`t'_ref1d if condition=="`cond'" & ntot==4000, meanonly
		local a = r(mean)
		quietly summarize raw_rej_`t'_ref2d if condition=="`cond'" & ntot==4000, meanonly
		local b = r(mean)
		quietly summarize raw_rej_`t'_refref if condition=="`cond'" & ntot==4000, meanonly
		local c = r(mean)
		quietly summarize raw_full_`t' if condition=="`cond'" & ntot==4000, meanonly
		local d = r(mean)
		di as res %8.3f `a' "          " %8.3f `b' "          " %8.3f `c' "          " %8.3f `d'

		foreach adj in bonf sidak holm fdr {
			di as txt "  `adj', n=1000:  " _continue
			quietly summarize `adj'_rej_`t'_ref1d if condition=="`cond'" & ntot==1000, meanonly
			local a = r(mean)
			quietly summarize `adj'_rej_`t'_ref2d if condition=="`cond'" & ntot==1000, meanonly
			local b = r(mean)
			quietly summarize `adj'_rej_`t'_refref if condition=="`cond'" & ntot==1000, meanonly
			local c = r(mean)
			quietly summarize `adj'_full_`t' if condition=="`cond'" & ntot==1000, meanonly
			local d = r(mean)
			di as res %8.3f `a' "          " %8.3f `b' "          " %8.3f `c' "          " %8.3f `d'

			di as txt "  `adj', n=4000:  " _continue
			quietly summarize `adj'_rej_`t'_ref1d if condition=="`cond'" & ntot==4000, meanonly
			local a = r(mean)
			quietly summarize `adj'_rej_`t'_ref2d if condition=="`cond'" & ntot==4000, meanonly
			local b = r(mean)
			quietly summarize `adj'_rej_`t'_refref if condition=="`cond'" & ntot==4000, meanonly
			local c = r(mean)
			quietly summarize `adj'_full_`t' if condition=="`cond'" & ntot==4000, meanonly
			local d = r(mean)
			di as res %8.3f `a' "          " %8.3f `b' "          " %8.3f `c' "          " %8.3f `d'
		}
	}
}

di as txt _n "============================================================"
di as txt "  (3) Omnibus rejection rates (consistency check vs. main study)"
di as txt "============================================================"

foreach cond in null bulk tail diffuse {
	di as txt _n "--- `cond' ---"
	foreach t in ks ad cvm {
		quietly summarize rej_`t'_omni if condition=="`cond'" & ntot==1000, meanonly
		local r1 = r(mean)
		quietly summarize rej_`t'_omni if condition=="`cond'" & ntot==4000, meanonly
		local r4 = r(mean)
		di as txt "  `t': n=1000 " as res %5.3f `r1' as txt "   n=4000 " as res %5.3f `r4'
	}
}

preserve
	collapse (mean) raw_any_ks raw_any_ad raw_any_cvm ///
	                bonf_any_ks bonf_any_ad bonf_any_cvm ///
	                sidak_any_ks sidak_any_ad sidak_any_cvm ///
	                holm_any_ks holm_any_ad holm_any_cvm ///
	                fdr_any_ks fdr_any_ad fdr_any_cvm ///
	                raw_rej_ks_ref1d raw_rej_ks_ref2d raw_rej_ks_refref raw_full_ks ///
	                raw_rej_ad_ref1d raw_rej_ad_ref2d raw_rej_ad_refref raw_full_ad ///
	                raw_rej_cvm_ref1d raw_rej_cvm_ref2d raw_rej_cvm_refref raw_full_cvm ///
	                bonf_rej_ks_ref1d bonf_rej_ks_ref2d bonf_rej_ks_refref bonf_full_ks ///
	                bonf_rej_ad_ref1d bonf_rej_ad_ref2d bonf_rej_ad_refref bonf_full_ad ///
	                bonf_rej_cvm_ref1d bonf_rej_cvm_ref2d bonf_rej_cvm_refref bonf_full_cvm ///
	                sidak_rej_ks_ref1d sidak_rej_ks_ref2d sidak_rej_ks_refref sidak_full_ks ///
	                sidak_rej_ad_ref1d sidak_rej_ad_ref2d sidak_rej_ad_refref sidak_full_ad ///
	                sidak_rej_cvm_ref1d sidak_rej_cvm_ref2d sidak_rej_cvm_refref sidak_full_cvm ///
	                holm_rej_ks_ref1d holm_rej_ks_ref2d holm_rej_ks_refref holm_full_ks ///
	                holm_rej_ad_ref1d holm_rej_ad_ref2d holm_rej_ad_refref holm_full_ad ///
	                holm_rej_cvm_ref1d holm_rej_cvm_ref2d holm_rej_cvm_refref holm_full_cvm ///
	                fdr_rej_ks_ref1d fdr_rej_ks_ref2d fdr_rej_ks_refref fdr_full_ks ///
	                fdr_rej_ad_ref1d fdr_rej_ad_ref2d fdr_rej_ad_refref fdr_full_ad ///
	                fdr_rej_cvm_ref1d fdr_rej_cvm_ref2d fdr_rej_cvm_refref fdr_full_cvm ///
	                (count) nreps=p_ks_omni, by(condition ntot)
	save "E:\ArielStuff\wtd_k_simulations\posthoc_summary.dta", replace
restore

di as txt _n "Done."
di as txt "Raw replicate-level data: posthoc_all.dta"
di as txt "Collapsed summary table: posthoc_summary.dta"
