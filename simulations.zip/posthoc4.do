* posthoc4

clear all
version 14

capture mkdir "E:\ArielStuff\wtd_k_simulations"

 local simreps   1000
 local testreps  1000

local ess_ratio 0.6

mata:
real vector sim_make_weights(real scalar n, real scalar ess_ratio)
{
	real scalar cv2, sigma2, mu
	real vector w

	if (ess_ratio >= 0.999) {
		return(J(n,1,1))
	}
	cv2    = 1/ess_ratio - 1
	sigma2 = ln(1+cv2)
	mu     = -sigma2/2
	w      = exp(rnormal(n,1,mu,sqrt(sigma2)))
	return(w)
}

real vector sim_gapfun(real vector p, real scalar gsize, real scalar p1, real scalar p2, real scalar width)
{
	real vector pa, ga, out
	real scalar i, j, n, m

	pa = (0.0005, p1-width, p1, p1+width, 0.50, p2-width, p2, p2+width, 0.9995)'
	ga = (0, 0, -gsize, 0, 0, 0, gsize, 0, 0)'

	n = rows(p)
	m = rows(pa)
	out = J(n, 1, .)
	for (i=1; i<=n; i++) {
		if (p[i] <= pa[1]) {
			out[i] = ga[1]
		}
		else if (p[i] >= pa[m]) {
			out[i] = ga[m]
		}
		else {
			for (j=1; j<m; j++) {
				if (p[i] >= pa[j] & p[i] <= pa[j+1]) {
					out[i] = ga[j] + (ga[j+1]-ga[j]) * (p[i]-pa[j])/(pa[j+1]-pa[j])
					j = m
				}
			}
		}
	}
	return(out)
}
end

capture program drop simreps_diffuse
program define simreps_diffuse, rclass
	args n0 n1 n2 ess_ratio testreps

	clear
	local ntot = `n0' + `n1' + `n2'
	quietly set obs `ntot'

	quietly gen byte group = 0            if _n <= `n0'
	quietly replace group  = 1            if _n >  `n0' & _n <= `n0'+`n1'
	quietly replace group  = 2            if _n >  `n0'+`n1'
	quietly gen double p   = runiform()

	quietly gen double y = 50 + 10*invnormal(p) + (group==2)*1

	mata: st_store(., st_addvar("double","wgt"), sim_make_weights(`ntot', `ess_ratio'))

	foreach t in ks ad cvm {
		quietly `t'test y [pweight=wgt], by(group) reps(`testreps') posthoc
		return scalar p_`t'_omni = r(p)
		matrix PH_`t' = r(pairwise)
		return scalar p_`t'_refref     = PH_`t'[1,2]
		return scalar p_`t'_ref1d      = PH_`t'[2,2]
		return scalar p_`t'_ref2d      = PH_`t'[3,2]
		return scalar bonf_`t'_refref  = PH_`t'[1,3]
		return scalar bonf_`t'_ref1d   = PH_`t'[2,3]
		return scalar bonf_`t'_ref2d   = PH_`t'[3,3]
		return scalar sidak_`t'_refref = PH_`t'[1,4]
		return scalar sidak_`t'_ref1d  = PH_`t'[2,4]
		return scalar sidak_`t'_ref2d  = PH_`t'[3,4]
		return scalar holm_`t'_refref  = PH_`t'[1,5]
		return scalar holm_`t'_ref1d   = PH_`t'[2,5]
		return scalar holm_`t'_ref2d   = PH_`t'[3,5]
		return scalar fdr_`t'_refref   = PH_`t'[1,6]
		return scalar fdr_`t'_ref1d    = PH_`t'[2,6]
		return scalar fdr_`t'_ref2d    = PH_`t'[3,6]
	}
end

local simvars ""
foreach t in ks ad cvm {
	local simvars `"`simvars' p_`t'_omni=r(p_`t'_omni)"'
	foreach pair in refref ref1d ref2d {
		local simvars `"`simvars' p_`t'_`pair'=r(p_`t'_`pair')"'
		foreach adj in bonf sidak holm fdr {
			local simvars `"`simvars' `adj'_`t'_`pair'=r(`adj'_`t'_`pair')"'
		}
	}
}

tempfile results
local first = 1

local sizelist_n0 300 1200
local sizelist_n1 300 1200
local sizelist_n2 400 1600
local nsizes : word count `sizelist_n0'

forvalues s = 1/`nsizes' {
	local n0  : word `s' of `sizelist_n0'
	local n1  : word `s' of `sizelist_n1'
	local n2  : word `s' of `sizelist_n2'
	local ntot = `n0' + `n1' + `n2'

	di as txt _n "=== DIFFUSE (post-hoc): n0=`n0' n1=`n1' n2=`n2' (total=`ntot') ==="

	simulate `simvars', reps(`simreps') seed(340`s'): ///
		simreps_diffuse `n0' `n1' `n2' `ess_ratio' `testreps'

	quietly gen long  ntot = `ntot'
	quietly gen str12 condition = "diffuse"

	if `first' {
		save `results', replace
		local first = 0
	}
	else {
		append using `results'
		save `results', replace
	}
}

use `results', clear
save "E:\ArielStuff\wtd_k_simulations\posthoc4.dta", replace
di as txt _n "Saved: E:\ArielStuff\wtd_k_simulations\posthoc4.dta"
