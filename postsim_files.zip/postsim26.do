* postsim26.do

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\revisions\postsim16.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim17.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim18.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim19.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim13.dta"
save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_est3_n2000_all.dta", replace

di as txt _n "=== k=3 estimated IPTW weights, application-like shares: n=500 vs n=2000 ==="
foreach cond in applike applike2000 {
	di as txt _n "--- `cond' ---"
	quietly count if condition == "`cond'"
	di as txt "  replications: " as res r(N)
	quietly summarize fail if condition == "`cond'", meanonly
	di as txt "  failed fits: " as res r(sum)
	foreach t in ks ad cvm {
		quietly summarize rej_`t'_ip if condition == "`cond'", meanonly
		local rr = r(mean)
		local se = sqrt(`rr' * (1 - `rr') / r(N))
		di as txt "  `t'  rejection rate = " as res %5.3f `rr' as txt "  (MC SE " as res %5.3f `se' as txt ")"
	}
	quietly summarize p_ad_ip if condition == "`cond'", detail
	di as txt "  AD p-value: min " as res %6.4f r(min) as txt "  median " as res %6.4f r(p50)
}

di as txt _n "=== Weight diagnostics (means) ==="
tabstat re_ip remin_ip wmax_ip n1 n2 n3, by(condition) statistics(mean) columns(statistics) format(%9.3f)

di as txt _n "=== n=2000: rejection by size of the two rare groups combined ==="
gen int rare = n2 + n3
xtile rare_q = rare if condition == "applike2000", nq(4)
tabstat rej_ks_ip rej_ad_ip rej_cvm_ip rare if condition == "applike2000", by(rare_q) statistics(mean n) columns(statistics) format(%9.3f)
