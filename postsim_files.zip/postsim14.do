* postsim14.do

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\revisions\postsim2.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim3.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim4.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim5.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim6.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim7.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim8.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim9.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim10.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim11.dta"

save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_scaling_all.dta", replace

collapse (mean) power_ks=rej_ks power_ad=rej_ad power_cvm=rej_cvm ///
         stat_ks stat_ad stat_cvm cv_ks cv_ad cv_cvm mn_ks mn_ad mn_cvm sd_ks sd_ad sd_cvm ///
         (count) nreps=rej_ks, by(condition ntot kgroups)
sort condition ntot kgroups

foreach t in ks ad cvm {
	gen double se_`t' = sqrt(power_`t' * (1 - power_`t') / nreps)
	gen double ratio_`t' = stat_`t' / cv_`t'
}

save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_scaling_summary.dta", replace

di as txt _n "=== Rejection rate by condition, n, and k ==="
list condition ntot kgroups nreps power_ks se_ks power_ad se_ad power_cvm se_cvm, sepby(condition ntot) noobs

di as txt _n "=== Mean observed statistic, mean permutation critical value, and their ratio ==="
list condition ntot kgroups stat_ks cv_ks ratio_ks stat_ad cv_ad ratio_ad stat_cvm cv_cvm ratio_cvm, sepby(condition ntot) noobs

di as txt _n "=== Permutation reference distribution: mean and sd (null condition) ==="
list ntot kgroups mn_ks sd_ks mn_ad sd_ad mn_cvm sd_cvm if condition == "null", sepby(ntot) noobs

clear
input str12 condition long ntot byte kgroups double(power_ks power_ad power_cvm)
"null"    1000 2 .055 .048 .050
"null"    2000 2 .044 .044 .046
"null"    3000 2 .043 .043 .042
"null"    4000 2 .055 .057 .057
"bulk"    1000 2 .449 .193 .146
"bulk"    2000 2 .840 .448 .323
"bulk"    3000 2 .973 .703 .579
"bulk"    4000 2 .996 .912 .828
"tail"    1000 2 .045 .114 .051
"tail"    2000 2 .049 .297 .060
"tail"    3000 2 .081 .655 .072
"tail"    4000 2 .137 .914 .072
"diffuse" 1000 2 .183 .215 .205
"diffuse" 2000 2 .309 .376 .358
"diffuse" 3000 2 .441 .512 .495
"diffuse" 4000 2 .536 .648 .618
end
save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_anchor_k2.dta", replace

use "E:\ArielStuff\wtd_k_simulations\sim_summary_3grp.dta", clear
gen byte kgroups = 3
keep condition ntot kgroups power_ks power_ad power_cvm
save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_anchor_k3.dta", replace

use "E:\ArielStuff\wtd_k_simulations\revisions\postsim_anchor_k2.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim_anchor_k3.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim_scaling_summary.dta"
keep condition ntot kgroups power_ks power_ad power_cvm
sort condition ntot kgroups
save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_power_k2_to_k10.dta", replace

foreach cond in null bulk tail diffuse {
	foreach nn in 1000 2000 3000 4000 {
		preserve
			keep if condition == "`cond'" & ntot == `nn'
			twoway (connected power_ks kgroups, lcolor(red) mcolor(red) msymbol(O)) ///
			       (connected power_ad kgroups, lcolor(blue) mcolor(blue) msymbol(D)) ///
			       (connected power_cvm kgroups, lcolor(green) mcolor(green) msymbol(T)), ///
			       yline(0.05, lpattern(dash) lcolor(gs10)) ///
			       xlabel(2 3 4 5 6 8 10) ///
			       legend(order(1 "KS" 2 "AD" 3 "CVM")) ///
			       ytitle("Rejection rate at 0.05") xtitle("Number of groups (k)") ///
			       title("`cond', n=`nn'") ///
			       name(postsim_`cond'_`nn', replace)
			graph export "E:\ArielStuff\wtd_k_simulations\revisions\postsim_`cond'_`nn'.png", replace width(1200)
		restore
	}
}

di as txt _n "Done."
