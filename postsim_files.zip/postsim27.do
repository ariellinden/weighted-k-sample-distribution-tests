* postsim27.do

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\revisions\postsim20.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim21.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim22.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim23.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim24.dta"
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim25.dta"

save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_pi_all.dta", replace

gen double pi = ndisc / ntot

collapse (mean) power_ks=rej_ks power_ad=rej_ad power_cvm=rej_cvm ///
         stat_ks stat_ad stat_cvm cv_ks cv_ad cv_cvm ///
         (count) nreps=rej_ks, by(condition ntot kgroups ndisc pi)
sort condition pi

foreach t in ks ad cvm {
	gen double se_`t' = sqrt(power_`t' * (1 - power_`t') / nreps)
	gen double ratio_`t' = stat_`t' / cv_`t'
}

save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_pi_summary.dta", replace

di as txt _n "=== k=6, n=2000: rejection rate by discrepant share (pi) ==="
list condition pi nreps power_ks se_ks power_ad se_ad power_cvm se_cvm, sepby(condition) noobs

di as txt _n "=== Mean observed statistic, mean critical value, and their ratio ==="
list condition pi stat_ks cv_ks ratio_ks stat_ad cv_ad ratio_ad stat_cvm cv_cvm ratio_cvm, sepby(condition) noobs

foreach cond in bulk tail diffuse {
	preserve
		keep if condition == "`cond'"
		twoway (connected power_ks pi, lcolor(red) mcolor(red) msymbol(O)) ///
		       (connected power_ad pi, lcolor(blue) mcolor(blue) msymbol(D)) ///
		       (connected power_cvm pi, lcolor(green) mcolor(green) msymbol(T)), ///
		       yline(0.05, lpattern(dash) lcolor(gs10)) ///
		       xlabel(0.1 0.2 0.3 0.4) ///
		       legend(order(1 "KS" 2 "AD" 3 "CVM")) ///
		       ytitle("Rejection rate at 0.05") xtitle("Share of sample in the discrepant group") ///
		       title("`cond', k=6, n=2000") ///
		       name(postsim_pi_`cond', replace)
		graph export "E:\ArielStuff\wtd_k_simulations\revisions\postsim_pi_`cond'.png", replace width(1200)
	restore
}

di as txt _n "Done."
