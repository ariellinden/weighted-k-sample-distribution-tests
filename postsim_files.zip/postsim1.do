* postsim1.do

clear all
version 14

capture mkdir "E:\ArielStuff\wtd_k_simulations\revisions"

mata:
real vector sim_make_weights(real scalar n, real scalar ess_ratio)
{
	real scalar cv2, sigma2, mu
	real vector w

	if (ess_ratio >= 0.999) {
		return(J(n,1,1))
	}
	cv2    = 1/ess_ratio - 1
	sigma2 = ln(1+cv2)
	mu     = -sigma2/2
	w      = exp(rnormal(n,1,mu,sqrt(sigma2)))
	return(w)
}

real vector sim_gapfun(real vector p, real scalar gsize, real scalar p1, real scalar p2, real scalar width)
{
	real vector pa, ga, out
	real scalar i, j, n, m

	pa = (0.0005, p1-width, p1, p1+width, 0.50, p2-width, p2, p2+width, 0.9995)'
	ga = (0, 0, -gsize, 0, 0, 0, gsize, 0, 0)'

	n = rows(p)
	m = rows(pa)
	out = J(n, 1, .)
	for (i=1; i<=n; i++) {
		if (p[i] <= pa[1]) {
			out[i] = ga[1]
		}
		else if (p[i] >= pa[m]) {
			out[i] = ga[m]
		}
		else {
			for (j=1; j<m; j++) {
				if (p[i] >= pa[j] & p[i] <= pa[j+1]) {
					out[i] = ga[j] + (ga[j+1]-ga[j]) * (p[i]-pa[j])/(pa[j+1]-pa[j])
					j = m
				}
			}
		}
	}
	return(out)
}

real rowvector scl_stats(real colvector ws, real colvector lab, real scalar k, real colvector bidx, real colvector dupb, real colvector WF2, real colvector G, real colvector H)
{
	real scalar j, Wj, W2j, neTot, leadfac, ad
	real colvector ind, wj, C, Q, sb, den, ok

	Q = J(rows(bidx), 1, 0)
	neTot = 0
	for (j=1; j<=k; j++) {
		ind   = (lab :== j)
		wj    = ws :* ind
		Wj    = sum(wj)
		W2j   = sum(wj :* ws)
		neTot = neTot + Wj^2 / W2j
		C     = runningsum(wj)
		Q     = Q + C[bidx]:^2 :/ Wj
	}
	sb      = Q - WF2
	leadfac = (neTot - 1) / neTot
	den     = neTot * G - H
	ok      = (den :> 0)
	ad      = leadfac * sum(ok :* dupb :* sb :/ (ok :* den + (1 :- ok)))
	return((max(sb), ad, sum(sb)))
}

real rowvector scl_run(real colvector y, real colvector gidx, real colvector w, real scalar k, real scalar R)
{
	real scalar n, i, r, m, tiecount, Wtot
	real colvector idx, ys, ws, g0, lab, brk, dupc, bidx, cum, Fb, WF2, G, H, dupb, col
	real matrix S
	real rowvector obs, out

	n   = rows(y)
	idx = order(y, 1)
	ys  = y[idx]
	ws  = w[idx]
	g0  = gidx[idx]

	brk  = J(n, 1, 0)
	dupc = J(n, 1, 0)
	tiecount = 1
	for (i=1; i<=n-1; i++) {
		if (ys[i] != ys[i+1]) {
			brk[i]  = 1
			dupc[i] = tiecount
			tiecount = 1
		}
		else {
			tiecount = tiecount + 1
		}
	}

	bidx = selectindex(brk)
	cum  = runningsum(ws)
	Wtot = cum[n]
	Fb   = cum[bidx] / Wtot
	WF2  = Wtot * Fb:^2
	G    = Fb :* (1 :- Fb)
	dupb = dupc[bidx]
	H    = dupb / 4

	obs = scl_stats(ws, g0, k, bidx, dupb, WF2, G, H)

	S = J(R, 3, .)
	for (r=1; r<=R; r++) {
		lab = jumble(g0)
		S[r,.] = scl_stats(ws, lab, k, bidx, dupb, WF2, G, H)
	}

	m = floor(0.05 * (R + 1))
	out = J(1, 15, .)
	for (i=1; i<=3; i++) {
		col = sort(S[.,i], 1)
		out[5*(i-1)+1] = obs[i]
		out[5*(i-1)+2] = (1 + sum(S[.,i] :>= obs[i])) / (R + 1)
		out[5*(i-1)+3] = col[R - m + 1]
		out[5*(i-1)+4] = mean(S[.,i])
		out[5*(i-1)+5] = sqrt(variance(S[.,i]))
	}
	return(out)
}
end

set seed 20261022
set obs 300
gen byte group = floor((_n - 1) / 75)
gen double p = runiform()
gen double y = 50 + 10*invnormal(p) + (group == 3)*1
gen double gidx = group + 1
mata: st_store(., st_addvar("double","wgt"), sim_make_weights(300, 0.6))

mata: st_matrix("chk", scl_run(st_data(., "y"), st_data(., "gidx"), st_data(., "wgt"), 4, 500))

kstest y [pweight=wgt], by(group) reps(500)
scalar rel_stat_ks = r(stat)
scalar rel_p_ks    = r(p)

adtest y [pweight=wgt], by(group) reps(500)
scalar rel_stat_ad = r(stat)
scalar rel_p_ad    = r(p)

cvmtest y [pweight=wgt], by(group) reps(500)
scalar rel_stat_cvm = r(stat)
scalar rel_p_cvm    = r(p)

di as txt _n "Observed statistics: Mata routine vs released commands (k=4, n=300); expect abs diff below about 1e-8"
di as txt "           mata          released      abs diff"
di as txt "KS    " as res %12.6f chk[1,1]  "  " %12.6f scalar(rel_stat_ks)  "  " %12.2e abs(chk[1,1]  - scalar(rel_stat_ks))
di as txt "AD    " as res %12.6f chk[1,6]  "  " %12.6f scalar(rel_stat_ad)  "  " %12.2e abs(chk[1,6]  - scalar(rel_stat_ad))
di as txt "CVM   " as res %12.6f chk[1,11] "  " %12.6f scalar(rel_stat_cvm) "  " %12.2e abs(chk[1,11] - scalar(rel_stat_cvm))

di as txt _n "Permutation p-values (different random permutations; should agree within Monte Carlo error, SE about .02)"
di as txt "KS    " as res %6.3f chk[1,2]  "  " %6.3f scalar(rel_p_ks)
di as txt "AD    " as res %6.3f chk[1,7]  "  " %6.3f scalar(rel_p_ad)
di as txt "CVM   " as res %6.3f chk[1,12] "  " %6.3f scalar(rel_p_cvm)

di as txt _n "Permutation reference summaries from the Mata routine (R=500)"
di as txt "           critical value      mean        sd"
di as txt "KS    " as res %14.5f chk[1,3]  "  " %9.5f chk[1,4]  "  " %9.5f chk[1,5]
di as txt "AD    " as res %14.5f chk[1,8]  "  " %9.5f chk[1,9]  "  " %9.5f chk[1,10]
di as txt "CVM   " as res %14.5f chk[1,13] "  " %9.5f chk[1,14] "  " %9.5f chk[1,15]

clear
set obs 4000
gen byte group = floor((_n - 1) / 400)
gen double p = runiform()
gen double y = 50 + 10*invnormal(p)
gen double gidx = group + 1
mata: st_store(., st_addvar("double","wgt"), sim_make_weights(4000, 0.6))

timer clear 1
timer on 1
mata: st_matrix("tm", scl_run(st_data(., "y"), st_data(., "gidx"), st_data(., "wgt"), 10, 500))
timer off 1
quietly timer list 1
di as txt _n "Timing, one replicate at k=10, n=4000, R=500 (the slowest cell type): " as res %8.3f r(t1) as txt " seconds"
di as txt "Projected for 2000 replicates: " as res %8.2f r(t1)*2000/3600 as txt " hours per cell"
