* postsim15.do

clear all
version 14

use "E:\ArielStuff\wtd_k_simulations\revisions\postsim12.dta", clear
append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim13.dta"
save "E:\ArielStuff\wtd_k_simulations\revisions\postsim_est3_all.dta", replace

di as txt _n "=== k=3 estimated IPTW weights, null: rejection rates by cell ==="
foreach cond in balanced applike {
	di as txt _n "--- `cond' ---"
	quietly summarize fail if condition == "`cond'", meanonly
	di as txt "  failed fits: " as res r(sum)
	foreach t in ks ad cvm {
		quietly summarize rej_`t'_ip if condition == "`cond'", meanonly
		local rr = r(mean)
		local se = sqrt(`rr' * (1 - `rr') / r(N))
		di as txt "  `t'  rejection rate = " as res %5.3f `rr' as txt "  (MC SE " as res %5.3f `se' as txt ")"
	}
}

di as txt _n "=== Weight diagnostics (means) ==="
tabstat re_ip remin_ip wmax_ip n1 n2 n3, by(condition) statistics(mean) columns(statistics) format(%9.3f)
