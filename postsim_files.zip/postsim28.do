* postsim28.do

version 14

local gvar  nom_treat
local wvar  medscore_mmws
local nperm 1000

capture mata: mata drop sne()

preserve
quietly drop if missing(`gvar') | missing(`wvar')

mata:
real scalar sne(real colvector w, real colvector g, real colvector lv)
{
	real scalar j, s
	s = 0
	for (j=1; j<=rows(lv); j++) {
		s = s + sum(select(w, g:==lv[j]))^2 / sum(select(w, g:==lv[j]):^2)
	}
	return(s)
}

g  = st_data(., "`gvar'")
w  = st_data(., "`wvar'")
lv = uniqrows(g)
k  = rows(lv)
nr = `nperm'

neObs  = sne(w, g, lv)
nePool = sum(w)^2 / sum(w:^2)

ne = J(nr, 1, .)
for (r=1; r<=nr; r++) {
	ne[r] = sne(w, jumble(g), lv)
}
s = sort(ne, 1)

printf("\n{txt}Groups: %g   observations: %g\n", k, rows(g))
for (j=1; j<=k; j++) {
	wj  = select(w, g:==lv[j])
	printf("{txt}  group %g: n = %6.0f   Kish effective n = %8.1f   Kish ratio = %5.3f\n", lv[j], rows(wj), sum(wj)^2/sum(wj:^2), (sum(wj)^2/sum(wj:^2))/rows(wj))
}
printf("\n{txt}Sum of group-wise Kish effective sizes, observed grouping : {res}%9.1f\n", neObs)
printf("{txt}Pooled Kish effective size (label-invariant)              : {res}%9.1f\n", nePool)
printf("{txt}Same sum under %g label permutations:\n", nr)
printf("{txt}  median            : {res}%9.1f\n", s[ceil(0.500*nr)])
printf("{txt}  2.5th percentile  : {res}%9.1f\n", s[ceil(0.025*nr)])
printf("{txt}  97.5th percentile : {res}%9.1f\n", s[ceil(0.975*nr)])
printf("{txt}Ratio, permutation median / observed : {res}%6.3f\n\n", s[ceil(0.500*nr)]/neObs)
end

restore
