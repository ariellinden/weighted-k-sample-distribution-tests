* postsim5.do

clear all
version 14

capture mkdir "E:\ArielStuff\wtd_k_simulations\revisions"

local simreps   2000
local testreps  500
local ess_ratio 0.6

local jscen 2 2 4 4 4 4 4 4
local jk    4 10 5 5 5 8 8 10
local jn    3000 2000 1000 2000 3000 1000 3000 4000

mata:
real vector sim_make_weights(real scalar n, real scalar ess_ratio)
{
	real scalar cv2, sigma2, mu
	real vector w

	if (ess_ratio >= 0.999) {
		return(J(n,1,1))
	}
	cv2    = 1/ess_ratio - 1
	sigma2 = ln(1+cv2)
	mu     = -sigma2/2
	w      = exp(rnormal(n,1,mu,sqrt(sigma2)))
	return(w)
}

real vector sim_gapfun(real vector p, real scalar gsize, real scalar p1, real scalar p2, real scalar width)
{
	real vector pa, ga, out
	real scalar i, j, n, m

	pa = (0.0005, p1-width, p1, p1+width, 0.50, p2-width, p2, p2+width, 0.9995)'
	ga = (0, 0, -gsize, 0, 0, 0, gsize, 0, 0)'

	n = rows(p)
	m = rows(pa)
	out = J(n, 1, .)
	for (i=1; i<=n; i++) {
		if (p[i] <= pa[1]) {
			out[i] = ga[1]
		}
		else if (p[i] >= pa[m]) {
			out[i] = ga[m]
		}
		else {
			for (j=1; j<m; j++) {
				if (p[i] >= pa[j] & p[i] <= pa[j+1]) {
					out[i] = ga[j] + (ga[j+1]-ga[j]) * (p[i]-pa[j])/(pa[j+1]-pa[j])
					j = m
				}
			}
		}
	}
	return(out)
}

real rowvector scl_stats(real colvector ws, real colvector lab, real scalar k, real colvector bidx, real colvector dupb, real colvector WF2, real colvector G, real colvector H)
{
	real scalar j, Wj, W2j, neTot, leadfac, ad
	real colvector ind, wj, C, Q, sb, den, ok

	Q = J(rows(bidx), 1, 0)
	neTot = 0
	for (j=1; j<=k; j++) {
		ind   = (lab :== j)
		wj    = ws :* ind
		Wj    = sum(wj)
		W2j   = sum(wj :* ws)
		neTot = neTot + Wj^2 / W2j
		C     = runningsum(wj)
		Q     = Q + C[bidx]:^2 :/ Wj
	}
	sb      = Q - WF2
	leadfac = (neTot - 1) / neTot
	den     = neTot * G - H
	ok      = (den :> 0)
	ad      = leadfac * sum(ok :* dupb :* sb :/ (ok :* den + (1 :- ok)))
	return((max(sb), ad, sum(sb)))
}

real rowvector scl_run(real colvector y, real colvector gidx, real colvector w, real scalar k, real scalar R)
{
	real scalar n, i, r, m, tiecount, Wtot
	real colvector idx, ys, ws, g0, lab, brk, dupc, bidx, cum, Fb, WF2, G, H, dupb, col
	real matrix S
	real rowvector obs, out

	n   = rows(y)
	idx = order(y, 1)
	ys  = y[idx]
	ws  = w[idx]
	g0  = gidx[idx]

	brk  = J(n, 1, 0)
	dupc = J(n, 1, 0)
	tiecount = 1
	for (i=1; i<=n-1; i++) {
		if (ys[i] != ys[i+1]) {
			brk[i]  = 1
			dupc[i] = tiecount
			tiecount = 1
		}
		else {
			tiecount = tiecount + 1
		}
	}

	bidx = selectindex(brk)
	cum  = runningsum(ws)
	Wtot = cum[n]
	Fb   = cum[bidx] / Wtot
	WF2  = Wtot * Fb:^2
	G    = Fb :* (1 :- Fb)
	dupb = dupc[bidx]
	H    = dupb / 4

	obs = scl_stats(ws, g0, k, bidx, dupb, WF2, G, H)

	S = J(R, 3, .)
	for (r=1; r<=R; r++) {
		lab = jumble(g0)
		S[r,.] = scl_stats(ws, lab, k, bidx, dupb, WF2, G, H)
	}

	m = floor(0.05 * (R + 1))
	out = J(1, 15, .)
	for (i=1; i<=3; i++) {
		col = sort(S[.,i], 1)
		out[5*(i-1)+1] = obs[i]
		out[5*(i-1)+2] = (1 + sum(S[.,i] :>= obs[i])) / (R + 1)
		out[5*(i-1)+3] = col[R - m + 1]
		out[5*(i-1)+4] = mean(S[.,i])
		out[5*(i-1)+5] = sqrt(variance(S[.,i]))
	}
	return(out)
}
end

capture program drop scl_prog
program define scl_prog, rclass
	args scen k ntot ndisc ess_ratio testreps

	clear
	quietly set obs `ntot'

	local nref = `ntot' - `ndisc'
	local km1  = `k' - 1
	local base = floor(`nref' / `km1')
	local rem  = `nref' - `base' * `km1'

	quietly gen byte group = `k' - 1
	local start = 1
	forvalues j = 1/`km1' {
		local sz   = `base' + (`j' <= `rem')
		local stop = `start' + `sz' - 1
		quietly replace group = `j' - 1 in `start'/`stop'
		local start = `stop' + 1
	}

	quietly gen double p = runiform()

	if `scen' == 1 {
		quietly gen double y = 50 + 10*invnormal(p)
	}
	else if `scen' == 2 {
		mata: st_store(., st_addvar("double","gapval"), sim_gapfun(st_data(.,"p"), 6, 0.25, 0.75, 0.05))
		quietly gen double y = 50 + 10*invnormal(p) + (group == `k' - 1)*gapval
	}
	else if `scen' == 3 {
		mata: st_store(., st_addvar("double","gapval"), sim_gapfun(st_data(.,"p"), 50, 0.05, 0.95, 0.02))
		quietly gen double y = 50 + 10*invnormal(p) + (group == `k' - 1)*gapval
	}
	else {
		quietly gen double y = 50 + 10*invnormal(p) + (group == `k' - 1)*1
	}

	quietly gen double gidx = group + 1

	mata: st_store(., st_addvar("double","wgt"), sim_make_weights(`ntot', `ess_ratio'))
	mata: st_matrix("scl_out", scl_run(st_data(., "y"), st_data(., "gidx"), st_data(., "wgt"), `k', `testreps'))

	return scalar stat_ks  = scl_out[1,1]
	return scalar p_ks     = scl_out[1,2]
	return scalar cv_ks    = scl_out[1,3]
	return scalar mn_ks    = scl_out[1,4]
	return scalar sd_ks    = scl_out[1,5]
	return scalar stat_ad  = scl_out[1,6]
	return scalar p_ad     = scl_out[1,7]
	return scalar cv_ad    = scl_out[1,8]
	return scalar mn_ad    = scl_out[1,9]
	return scalar sd_ad    = scl_out[1,10]
	return scalar stat_cvm = scl_out[1,11]
	return scalar p_cvm    = scl_out[1,12]
	return scalar cv_cvm   = scl_out[1,13]
	return scalar mn_cvm   = scl_out[1,14]
	return scalar sd_cvm   = scl_out[1,15]
end

local simvars ""
foreach t in ks ad cvm {
	foreach m in stat p cv mn sd {
		local simvars `"`simvars' `m'_`t'=r(`m'_`t')"'
	}
}

local ncell : word count `jscen'

forvalues c = 1/`ncell' {
	local scen : word `c' of `jscen'
	local k    : word `c' of `jk'
	local ntot : word `c' of `jn'
	local ndisc = round(0.4 * `ntot')
	local sd = 100000 * `scen' + 100 * `k' + `ntot' / 1000
	local cond : word `scen' of null bulk tail diffuse

	di as txt _n "=== postsim5: cell `c' of `ncell': `cond', k=`k', n=`ntot', ndisc=`ndisc', started `c(current_time)' ==="

	simulate `simvars', reps(`simreps') seed(`sd'): ///
		scl_prog `scen' `k' `ntot' `ndisc' `ess_ratio' `testreps'

	quietly gen byte rej_ks  = (p_ks  < 0.05)
	quietly gen byte rej_ad  = (p_ad  < 0.05)
	quietly gen byte rej_cvm = (p_cvm < 0.05)
	quietly gen byte kgroups = `k'
	quietly gen long ntot    = `ntot'
	quietly gen long ndisc   = `ndisc'
	quietly gen str12 condition = "`cond'"

	foreach t in ks ad cvm {
		quietly summarize rej_`t', meanonly
		di as txt "  `t' rejection rate = " as res %5.3f r(mean)
	}

	if `c' > 1 {
		append using "E:\ArielStuff\wtd_k_simulations\revisions\postsim5.dta"
	}
	save "E:\ArielStuff\wtd_k_simulations\revisions\postsim5.dta", replace
}

di as txt _n "Finished postsim5: `c(current_time)'"
