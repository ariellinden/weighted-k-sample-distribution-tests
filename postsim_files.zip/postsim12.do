* postsim12.do

clear all
version 14

capture mkdir "E:\ArielStuff\wtd_k_simulations\revisions"

local simreps  2000
local testreps 500
local nobs     500
local b2       -0.469466
local b3       -0.469466
local sd       7110

capture program drop est3_rep
program define est3_rep, rclass
	args b2 b3 lam n testreps

	clear
	quietly set obs `n'
	quietly gen double x1   = rnormal()
	quietly gen double x1sq = x1^2
	quietly gen double eta2 = `b2' + `lam'*( 0.90*x1 + 0.25*x1sq)
	quietly gen double eta3 = `b3' + `lam'*(-0.90*x1 + 0.25*x1sq)
	quietly gen double den  = 1 + exp(eta2) + exp(eta3)
	quietly gen double pr1  = 1/den
	quietly gen double pr2  = exp(eta2)/den
	quietly gen double u    = runiform()
	quietly gen byte   a    = 1 + (u > pr1) + (u > pr1 + pr2)
	quietly gen double y    = 50 + 7.5*x1 + 10*invnormal(runiform())

	foreach nm in p_ks_ip p_ad_ip p_cvm_ip re_ip remin_ip wmax_ip {
		scalar e3_`nm' = .
	}
	scalar e3_fail = 0

	forvalues j = 1/3 {
		quietly count if a == `j'
		scalar e3_n`j' = r(N)
	}

	capture quietly mlogit a x1 x1sq, baseoutcome(1)
	if _rc != 0 {
		scalar e3_fail = 1
	}
	else if e(converged) == 0 {
		scalar e3_fail = 1
	}

	if scalar(e3_fail) == 0 {
		quietly predict double e1 e2 e3, pr
		quietly gen double ps = cond(a == 1, e1, cond(a == 2, e2, e3))
		quietly gen double w_ip = 1/ps

		foreach arm in ip {
			quietly gen double w2_`arm' = w_`arm'^2
			quietly summarize w_`arm'
			local sw  = r(sum)
			local wmx = r(max)
			local wmn = r(mean)
			quietly summarize w2_`arm'
			local sw2 = r(sum)
			scalar e3_re_`arm'   = (`sw'^2 / `sw2') / `n'
			scalar e3_wmax_`arm' = `wmx' / `wmn'

			local remin = .
			forvalues j = 1/3 {
				quietly summarize w_`arm' if a == `j'
				local swj = r(sum)
				local nj  = r(N)
				quietly summarize w2_`arm' if a == `j'
				local sw2j = r(sum)
				local rej = (`swj'^2 / `sw2j') / `nj'
				if `remin' == . | `rej' < `remin' {
					local remin = `rej'
				}
			}
			scalar e3_remin_`arm' = `remin'
		}

		foreach t in ks ad cvm {
			quietly `t'test y [pweight=w_ip], by(a) reps(`testreps')
			scalar e3_p_`t'_ip = r(p)
		}
	}

	foreach nm in p_ks_ip p_ad_ip p_cvm_ip re_ip remin_ip wmax_ip {
		return scalar `nm' = scalar(e3_`nm')
	}
	return scalar fail = scalar(e3_fail)
	return scalar n1   = scalar(e3_n1)
	return scalar n2   = scalar(e3_n2)
	return scalar n3   = scalar(e3_n3)
end

local simvars ""
foreach nm in p_ks_ip p_ad_ip p_cvm_ip re_ip remin_ip wmax_ip fail n1 n2 n3 {
	local simvars `"`simvars' `nm'=r(`nm')"'
}

di as txt _n "=== postsim12: k=3 estimated IPTW weights, null, balanced (b2=`b2' b3=`b3') n=`nobs', started `c(current_time)' ==="

simulate `simvars', reps(`simreps') seed(`sd'): ///
	est3_rep `b2' `b3' 1 `nobs' `testreps'

quietly gen str10 condition = "balanced"

quietly summarize fail, meanonly
di as txt "  propensity-model fits failed or did not converge: " as res r(sum) as txt " of `simreps'"

foreach t in ks ad cvm {
	quietly gen byte rej_`t'_ip = (p_`t'_ip < 0.05) if p_`t'_ip < .
	quietly summarize rej_`t'_ip, meanonly
	local rr = r(mean)
	local se = sqrt(`rr' * (1 - `rr') / r(N))
	di as txt "  iptw  `t'  rejection rate = " as res %5.3f `rr' as txt "  (MC SE " as res %5.3f `se' as txt ")"
}
quietly summarize re_ip, meanonly
di as txt "  iptw  mean overall Kish ratio = " as res %5.3f r(mean)

save "E:\ArielStuff\wtd_k_simulations\revisions\postsim12.dta", replace
di as txt _n "Finished postsim12: `c(current_time)'"
